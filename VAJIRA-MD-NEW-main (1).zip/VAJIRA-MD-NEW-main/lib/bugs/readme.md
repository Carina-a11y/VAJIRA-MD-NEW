vajira
