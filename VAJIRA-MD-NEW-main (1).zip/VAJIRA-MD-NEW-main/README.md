<div align="center">
     
 [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=F01&lines=ＶＡＪＩＲＡ+ＭＤ+ＷＨＡＴＳＡＰＰ+ＢＯＴ)](https://git.io/typing-svg)

## FIXING  ALL ERRORS IN NEXT UPDATE WAIT..... 

  
<div align="center">
</p

<hr>

<hr>

<p align="center">
<a href="https://github.com/VajiraTech">
    <img src="https://telegra.ph/file/235d945df230d71f246b6.jpg"  width="700px">
</a>
<hr>

<hr>


## JOIN MY WHATSAPP CHANNEL

[![vajira](https://telegra.ph/file/99460844d012cad1b7ee4.jpg)](https://whatsapp.com/channel/0029VahMZasD8SE5GRwzqn3Z)



<b><details><summary>𝗦𝗢𝗖𝗜𝗔𝗟 𝗧𝗬𝗣𝗘𝗦</summary><br>

## CONTACT OWNER

[![vajira](https://telegra.ph/file/99460844d012cad1b7ee4.jpg)](https://wa.me/94719199757)

## JOIN SUPPORT GROUP

[![vajira](https://telegra.ph/file/99460844d012cad1b7ee4.jpg)](https://chat.whatsapp.com/D6w6Qy5yrhp7MmfNcprbO3)

## MY YT CHANNEL

[![Youtube](https://telegra.ph/file/eebe86c26e98ffeae39ea.jpg)](https://youtube.com/@gamingewingyt6216) 

</details>

***Click [FORK](https://github.com/VajiraTech/VAJIRA-MD-NEW-fork)***

***Click [My web](https://vajira-api-7967fdc132a8.herokuapp.com/)***

<hr>

<hr>


## DEPLOY BY SESSION ID or creds.json (Qr code)


<a href="https://tall-buffy-vajiratech-a63ef97e.koyeb.app/"><img src="https://i.ibb.co/5BGSVZw/pair-code-btn-zusyco.png" alt="PAIR-CODE" border="2" width="170" height="41" ></a>


<hr>

<hr>

## DEPLOYMENT METHODS

[CLICK TO SELECT DEPLOY PLATFORM](https://vajiratech.github.io/VAJIRA-DEPLOY/QUEEN-IZUMI-WEB-main/projects/deployment.html)

<hr>

<hr>

</div>

</div>


## HOW TO DEPLOY 🧚 VAJIRA - ＭＤ 🧚

1) 𝙵𝙸𝚁𝚂𝚃 𝙵𝙾𝚁𝙺 𝚃𝙷𝙴 𝚁𝙴𝙿𝙾.
2) 𝚂𝙲𝙰𝙽 𝚃𝙷𝙴 𝚀𝚁 𝚃𝙷𝙴𝙽 𝚆𝙸𝙻𝙻 𝙲𝙾𝙼𝙴 𝚂𝙴𝚂𝚂𝙸𝙾𝙽 𝙸𝙳.
4) 𝙰𝙽𝙳 𝚂𝙴𝙻𝙴𝙲𝚃 𝙵𝙾𝚁𝙺 𝚁𝙴𝙿𝚘 𝙰𝙽𝙳 𝙳𝙴𝙿𝙻𝙾𝚈 𝚃𝙷𝙴 𝙱𝙾𝚃.
5) 𝙿𝚄𝚃 𝙳𝚈𝙽𝙾 𝚃𝙾 𝙿𝚁𝙾𝙵𝙴𝚂𝚂𝙸𝙾𝙽𝙰𝙻 𝙰𝙽𝙳 𝙿𝚄𝚃 𝙸𝚃 2𝚡.
6) 𝙽𝙾𝚆 𝙴𝙽𝙹𝙾𝚈 𝚃𝙷𝙴 𝚅𝙰𝙹𝙸𝚁𝙰 𝙼𝙳 𝙱𝙾𝚃.


## THANKS TO 👨‍💻

• Asif King - Web Design

• Kasun - Testing

• Danidu Nirmal - Logo Design

• Ushani - Voice Helper


